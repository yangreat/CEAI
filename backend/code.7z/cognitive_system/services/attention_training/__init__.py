"""
Attention Training service module.
""" 