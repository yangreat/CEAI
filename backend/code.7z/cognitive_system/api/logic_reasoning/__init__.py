"""
Logic reasoning module for cognitive empowerment.
"""

from cognitive_system.api.logic_reasoning.router import router

__all__ = ["router"] 