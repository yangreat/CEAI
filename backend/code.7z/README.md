# Cognitive Empowerment System

A comprehensive backend system for cognitive training applications designed to help users improve various cognitive abilities including memory, attention, executive function, language ability, logic and reasoning, and emotion regulation.

## Features

- **Logic and Reasoning Training**: Play Gomoku (Five in a Row) against an AI powered by AgentScope
- **Emotion Regulation Training**: Detect and analyze emotions to help users understand and manage their feelings
- **Chatbot System**: Interactive text and speech-based chatbot for cognitive training exercises

## Installation

### Prerequisites

- Python 3.9 or higher
- pip (Python package manager)

### Setup

1. Clone the repository:
   ```
   git clone <repository-url>
   cd cognitive-system
   ```

2. Create and activate a virtual environment:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Set up environment variables:
   ```
   cp .env.example .env
   ```
   Edit the `.env` file to add your API keys and configure settings:
   - `API_KEY`: Your OpenAI or other compatible API key
   - `BASE_URL`: API base URL (default: https://api.chatanywhere.tech/v1)
   - `DEFAULT_MODEL`: Default model to use (e.g., gpt-3.5-turbo-1106)

## Running the Application

Start the FastAPI server:

```
python cognitive_system\main.py

or

python -m uvicorn cognitive_system.main:app  (Recommended)
```

The API will be available at `http://localhost:8000`.

## Using the Gomoku Game

The Gomoku game API endpoints are available at `/logic-reasoning/gomoku/`. Here's how to use them:

1. **Create a new game**:
   ```
   POST /logic-reasoning/gomoku/create
   ```
   Request body:
   ```json
   {
     "model_type": "openai_chat",
     "difficulty": "medium",
     "board_size": 15
   }
   ```
   This returns a game ID that you'll use for subsequent requests.

2. **Make a move**:
   ```
   POST /logic-reasoning/gomoku/{game_id}/move
   ```
   Request body:
   ```json
   {
     "row": 7,
     "col": 7
   }
   ```
   This makes your move and gets the AI's response.

3. **Get the game state**:
   ```
   GET /logic-reasoning/gomoku/{game_id}/state
   ```
   This returns the current state of the game.

4. **Reset the game**:
   ```
   POST /logic-reasoning/gomoku/{game_id}/reset
   ```
   This resets the game to its initial state.

5. **Change difficulty**:
   ```
   POST /logic-reasoning/gomoku/{game_id}/difficulty
   ```
   Request body:
   ```json
   {
     "difficulty": "hard"
   }
   ```
   This changes the AI's difficulty level.

6. **Get a hint**:
   ```
   GET /logic-reasoning/gomoku/{game_id}/hint
   ```
   This returns a hint for your next move.

## API Documentation

Once the server is running, you can access the interactive API documentation at:

- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## Architecture

The project is organized as follows:

```
cognitive_system/
├── api/                # API endpoints and request handlers
├── config/             # Configuration settings and utilities
├── services/           # Business logic for different system components
│   ├── chatbot/        # Chatbot implementation with text and speech capabilities
│   ├── emotion_regulation/  # Emotion detection and regulation functionality
│   └── logic_reasoning/     # Logic games and reasoning exercises
│       ├── board_agent.py   # AgentScope implementation of Gomoku board
│       ├── gomoku_agent.py  # AI agent for playing Gomoku
│       └── game_controller.py  # Controls game interactions
├── .env                # Environment variables
├── .env.example        # Example environment variables
├── main.py             # Application entry point
└── requirements.txt    # Project dependencies
```

## AgentScope Integration

The Gomoku game uses [AgentScope](https://github.com/modelscope/agentscope), an innovative multi-agent platform designed to empower developers to build multi-agent applications with large-scale models. The integration:

1. Uses the same API configuration as defined in the `.env` file
2. Creates intelligent agents for game play
3. Provides a conversational, agent-based gameplay experience

For more information on AgentScope, visit the [official documentation](https://modelscope.github.io/agentscope/). 